// Sample data for products
const products = [
    { name: 'لپتاپ 1', category: 'laptop', price: 3000000, color: 'red' },
    { name: 'تلفن همراه 1', category: 'phone', price: 1500000, color: 'blue' },
    { name: 'تلفن همراه 2', category: 'phone', price: 1800000, color: 'black' },
    { name: 'تلفن همراه 3', category: 'phone', price: 2000000, color: 'pink' },
    { name: 'تلفن همراه 4', category: 'phone', price: 2500000, color: 'green' },
    { name: 'لپتاپ 2', category: 'laptop', price: 3500000, color: 'white' },
    { name: 'لپتاپ 3', category: 'laptop', price: 3400000, color: 'black' },
    { name: 'لپتاپ 4', category: 'laptop', price: 4000000, color: 'blue' },
    { name: 'تبلت 1', category: 'ipad', price: 3500000, color: 'red' },
    { name: 'تبلت 2', category: 'ipad', price: 3550000, color: 'pink' },
    { name: 'تبلت 3', category: 'ipad', price: 3400000, color: 'black' },
    { name: 'تبلت 4', category: 'ipad', price: 4500000, color: 'blue' },
    { name: 'ساعت 1', category: 'watch', price: 1000000, color: 'red' },
    { name: 'ساعت 2', category: 'watch', price: 1100000, color: 'blue' },
    { name: 'ساعت 3', category: 'watch', price: 1100000, color: 'green' },
    { name: 'ساعت 4', category: 'watch', price: 1200000, color: 'pink' },
    { name: 'ساعت 5', category: 'watch', price: 1000000, color: 'white' },
    { name: 'ساعت 6', category: 'watch', price: 1000000, color: 'black' },
];

// Display initial products
displayProducts(products);

function applyFilters() {
    const category = $('#category').val();
    const price = $('#price').val();
    const color = $('#color').val();

    // Apply filters to products
    const filteredProducts = products.filter(product => {
        return (category === '' || product.category === category) &&
            (price === '' || product.price <= price) &&
            (color === '' || product.color === color);
    });

    // Display filtered products
    displayProducts(filteredProducts);
}

function clearFilters() {
    // Clear filter values and display all products
    $('#category').val('');
    $('#price').val('');
    $('#color').val('');
    displayProducts(products);
}

function displayProducts(products) {
    const productsContainer = $('.products');
    productsContainer.empty();

    products.forEach(product => {
        const productElement = $('<div class="product">').html(`
        <h4>${product.name}</h4>
        <p>دسته بندی: ${product.category}</p>
        <p>قیمت: ${product.price}</p>
        <p>رنگ: ${product.color}</p>
      `);
        productsContainer.append(productElement);
    });
}